from django.http import JsonResponse
from .models import Resource, UsageLog

def resource_list(request):
    resources = Resource.objects.all().values(
        "id", "name", "status", "category", "description"
    )
    resource_logs = {
        resource["id"]: list(
            UsageLog.objects.filter(resource_id=resource["id"]).values(
                "id", "user__username", "start_time", "end_time"
            )
        )
        for resource in resources
    }
    resources_with_logs = [
        {**resource, "usage_logs": resource_logs[resource["id"]]} for resource in resources
    ]
    return JsonResponse(resources_with_logs, safe=False)