from django.contrib import admin
from .models import Resource, UsageLog

admin.site.register(Resource)
admin.site.register(UsageLog)
