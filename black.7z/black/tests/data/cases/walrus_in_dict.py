# flags: --preview
# This is testing an issue that is specific to the preview style (wrap_long_dict_values_in_parens)
{
    "is_update": (up := commit.hash in update_hashes)
}

# output
# This is testing an issue that is specific to the preview style (wrap_long_dict_values_in_parens)
{"is_update": (up := commit.hash in update_hashes)}
