# flags: --minimum-version=3.10
class Plotter:
\
    pass

class AnotherCase:
  \
    """Some
    \
    Docstring
    """

# output

class Plotter:

    pass


class AnotherCase:
    """Some
    \
    Docstring
    """
