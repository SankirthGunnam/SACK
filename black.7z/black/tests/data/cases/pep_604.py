def some_very_long_name_function() -> my_module.Asdf | my_module.AnotherType | my_module.YetAnotherType | None:
    pass


def some_very_long_name_function() -> my_module.Asdf | my_module.AnotherType | my_module.YetAnotherType | my_module.EvenMoreType | None:
    pass


# output


def some_very_long_name_function() -> (
    my_module.Asdf | my_module.AnotherType | my_module.YetAnotherType | None
):
    pass


def some_very_long_name_function() -> (
    my_module.Asdf
    | my_module.AnotherType
    | my_module.YetAnotherType
    | my_module.EvenMoreType
    | None
):
    pass
