This is not valid Python syntax
y = "This is valid syntax"
