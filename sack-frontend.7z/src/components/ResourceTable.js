import React, { useState, useEffect } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Collapse,
  Box,
  Typography,
} from "@mui/material";
import { KeyboardArrowDown, KeyboardArrowUp } from "@mui/icons-material";

const ResourceTable = () => {
  const [resources, setResources] = useState([]);
  const [openRow, setOpenRow] = useState(null);

  useEffect(() => {
    // Fetch resources from Django backend API
    fetch("resources/api/resources/")
      .then((response) => response.json())
      .then((data) => setResources(data))
      .catch((error) => console.error("Error fetching resources:", error));
  }, []);

  const toggleRow = (resourceId) => {
    setOpenRow(openRow === resourceId ? null : resourceId);
  };

  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell />
            <TableCell>Resource Name</TableCell>
            <TableCell>Status</TableCell>
            <TableCell>Category</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {resources.map((resource) => (
            <React.Fragment key={resource.id}>
              <TableRow>
                <TableCell>
                  <IconButton onClick={() => toggleRow(resource.id)}>
                    {openRow === resource.id ? (
                      <KeyboardArrowUp />
                    ) : (
                      <KeyboardArrowDown />
                    )}
                  </IconButton>
                </TableCell>
                <TableCell>{resource.name}</TableCell>
                <TableCell>{resource.status}</TableCell>
                <TableCell>{resource.category || "N/A"}</TableCell>
              </TableRow>
              <TableRow>
                <TableCell colSpan={4} style={{ paddingBottom: 0, paddingTop: 0 }}>
                  <Collapse in={openRow === resource.id} timeout="auto" unmountOnExit>
                    <Box margin={2}>
                      <Typography variant="h6">{resource.name}</Typography>
                      <Typography variant="body2">Description: {resource.description}</Typography>
                      <Typography variant="body2">Status: {resource.status}</Typography>
                      <Typography variant="body2">Category: {resource.category}</Typography>
                      <Typography variant="h6">Usage Log:</Typography>
                      {resource.usage_logs.length > 0 ? (
                        <ul>
                          {resource.usage_logs.map((log) => (
                            <li key={log.id}>
                              <b>User:</b> {log.user} | <b>Start Time:</b> {log.start_time} | <b>End Time:</b> {log.end_time}
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <Typography>No usage history available.</Typography>
                      )}
                    </Box>
                  </Collapse>
                </TableCell>
              </TableRow>
            </React.Fragment>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default ResourceTable;
