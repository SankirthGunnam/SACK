import React from "react";
import ResourceTable from "./components/ResourceTable";
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Login from './components/Login';  // Import your login page
import HomePage from './HomePage';  // Import your homepage component

const App = () => {
  return (
    <Router>
      <Switch>
        <Route path="/login" component={Login} />
        <Route path="/home" component={HomePage} />
        <Route exact path="/" component={Login} />  {/* Default route */}
      </Switch>
    </Router>
  );
};

export default App;
